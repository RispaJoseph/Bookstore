import React, { useState, useEffect } from "react";
import { createBook, fetchBook, updateBook } from "../api";
import { useNavigate, useParams } from "react-router-dom";

export default function BookForm({ editMode = false }) {
  const { id } = useParams();
  const [form, setForm] = useState({ title: "", author: "", published_year: "", price: "" });
  const nav = useNavigate();

  useEffect(() => {
    if (editMode && id) {
      fetchBook(id).then(b => setForm({ title: b.title, author: b.author, published_year: b.published_year || "", price: b.price || "" }));
    }
  }, [editMode, id]);

  async function onSubmit(e) {
    e.preventDefault();
    try {
      if (editMode) await updateBook(id, form);
      else await createBook(form);
      nav("/books");
    } catch (err) {
        console.error("Error saving book:", err);
        alert("Failed to save");
        }
  }

  return (
    <form onSubmit={onSubmit}>
      <div><input placeholder="Title" value={form.title} onChange={e=>setForm({...form,title:e.target.value})} /></div>
      <div><input placeholder="Author" value={form.author} onChange={e=>setForm({...form,author:e.target.value})} /></div>
      <div><input placeholder="Published Year" value={form.published_year} onChange={e=>setForm({...form,published_year:e.target.value})} /></div>
      <div><input placeholder="Price" value={form.price} onChange={e=>setForm({...form,price:e.target.value})} /></div>
      <button type="submit">Save</button>
    </form>
  );
}
