import React, { useEffect, useState } from "react";
import { fetchBooks } from "../api";
import { Link } from "react-router-dom";

export default function BookList() {
  const [books, setBooks] = useState([]);
  const [q, setQ] = useState("");
  const [page, setPage] = useState(1);

  useEffect(() => {
    async function load() {
      const params = {};
      if (q) params.q = q;
      params.page = page;
      try {
        const data = await fetchBooks(params);
        if (data.results) setBooks(data.results);
        else setBooks(data);
      } catch (err) {
        console.error(err);
      }
    }
    load();
  }, [q, page]);

  return (
    <div>
      <h2>Books</h2>
      <div style={{ marginBottom: 8 }}>
        <input
          placeholder="Search title or author"
          value={q}
          onChange={e => setQ(e.target.value)}
        />
      </div>
      {books.map(b => (
        <div
          key={b.id}
          style={{ border: "1px solid #ddd", padding: 8, marginBottom: 8 }}
        >
          <h3><Link to={`/books/${b.id}`}>{b.title}</Link></h3>
          <div>by {b.author} • ₹{b.price}</div>
        </div>
      ))}
      <div style={{ marginTop: 12 }}>
        <button onClick={() => setPage(p => Math.max(1, p - 1))}>Prev</button>
        <span style={{ margin: "0 8px" }}>{page}</span>
        <button onClick={() => setPage(p => p + 1)}>Next</button>
      </div>
    </div>
  );
}
