import React, { useEffect, useState } from "react";
import { fetchBook, createOrder, verifyPayment, deleteBook } from "../api";
import { useParams, useNavigate, Link } from "react-router-dom";
import { useSelector } from "react-redux";

export default function BookDetail() {
  const { id } = useParams();
  const [book, setBook] = useState(null);
  const access = useSelector(s => s.auth.access);
  const nav = useNavigate();

  useEffect(() => {
    fetchBook(id).then(setBook).catch(console.error);
  }, [id]);

  async function handleBuy() {
    if (!access) { alert("Login required"); nav("/auth"); return; }
    try {
      const res = await createOrder(id); // returns order_id (paise in amount) and display_amount if backend set it
      const options = {
        key: res.key,
        amount: res.amount,
        currency: res.currency,
        name: book.title,
        description: book.author,
        order_id: res.order_id,
        handler: async function (response) {
          // send to backend verify
          const verifyRes = await verifyPayment(response);
          if (verifyRes.detail) alert("Payment: " + verifyRes.detail);
        }
      };
      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err) {
        console.error("Error creating order:", err);
        alert("Failed to create order");
        }
  }

  async function handleDelete() {
    if (!confirm("Delete this book?")) return;
    try {
      await deleteBook(id);
      alert("Deleted");
      nav("/books");
    } catch (err) {
        console.error("Error deleting book:", err);
        alert("Failed");
        }
  }

  if (!book) return <div>Loading...</div>;
  return (
    <div>
      <h2>{book.title}</h2>
      <div>Author: {book.author}</div>
      <div>Year: {book.published_year}</div>
      <div>Price: ₹{book.price}</div>
      <div style={{ marginTop: 12 }}>
        <button onClick={handleBuy}>Buy Now</button>
        {" "}
        {access && <Link to={`/books/${id}/edit`}><button>Edit</button></Link>}
        {" "}
        {access && <button onClick={handleDelete}>Delete</button>}
      </div>
    </div>
  );
}
