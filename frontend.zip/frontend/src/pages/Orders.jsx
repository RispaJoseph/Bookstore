import React, { useEffect, useState } from "react";
import { fetchMyOrders } from "../api";

export default function Orders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    async function load() {
      try {
        const data = await fetchMyOrders();
        setOrders(data);
      } catch (err) {
        console.error("Failed to fetch orders:", err.response ? err.response.data : err.message);
        alert("Failed to fetch orders");
      } finally {
        setLoading(false);
      }
    }
    load();
  }, []);

  if (loading) return <div>Loading orders...</div>;

  return (
    <div>
      <h2>My Orders</h2>
      {orders.length === 0 && <p>No orders yet.</p>}

      {orders.map((order) => (
        <div
          key={order.id}
          style={{ border: "1px solid #ddd", padding: 10, marginBottom: 10 }}
        >
          <p><strong>Book:</strong> {order.book.title}</p>
          <p><strong>Author:</strong> {order.book.author}</p>
          <p><strong>Amount Paid:</strong> ₹{(order.amount / 100).toFixed(2)}</p>
          <p><strong>Status:</strong> {order.status}</p>
          {order.razorpay_payment_id && (
            <p><strong>Payment ID:</strong> {order.razorpay_payment_id}</p>
          )}
        </div>
      ))}
    </div>
  );
}
