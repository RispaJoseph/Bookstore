import React from "react";
import { Link, useNavigate } from "react-router-dom";
import { useSelector, useDispatch } from "react-redux";
import { logout } from "../store/authSlice";

export default function Nav() {
  const access = useSelector(s => s.auth.access);
  const dispatch = useDispatch();
  const navigate = useNavigate();

  function handleLogout() {
    dispatch(logout());
    navigate("/auth");
  }

  return (
    <nav style={{ marginBottom: 20, display: "flex", gap: 12 }}>
      <Link to="/books">Books</Link>
      <Link to="/orders">My Orders</Link>
      {access ? (
        <>
          <Link to="/books/new">Add Book</Link>
          <button onClick={handleLogout}>Logout</button>
        </>
      ) : (
        <Link to="/auth">Login</Link>
      )}
    </nav>
  );
}
